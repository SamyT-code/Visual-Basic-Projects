﻿Public Class Form1
    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        Dim nom As String
        nom = Me.txtBoxNom.Text
        nom = "Bonjour " + nom + ","
        Me.Label1.Text = nom

        Dim intHeures As Single
        intHeures = Me.txtBoxHeures.Text
        intHeures = 35 * intHeures

        Me.Label3.Text = "Le prix associé à la main d'oeuvre est de"
        Me.Label4.Text = intHeures

        Dim intPieces As Integer
        intPieces = Me.txtBoxPieces.Text
        intPieces = 1.5 * intPieces

        Me.Label5.Text = "Le prix associé aux pièces est de"
        Me.Label6.Text = intPieces

        Dim total As Integer
        total = (intPieces + intHeures) * 1.13

        Me.Label7.Text = "Le total avec taxes est de :"
        Me.Label8.Text = total

        Dim soustotal As Integer
        soustotal = intPieces + intHeures

        Me.Label2.Text = "Le sous-total sans taxes est de :"
        Me.Label9.Text = soustotal



    End Sub
End Class
